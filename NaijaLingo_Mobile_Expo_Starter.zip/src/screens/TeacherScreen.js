import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Card, Muted, Screen, Stat, Title } from '../components/UI';

export default function TeacherScreen() {
  return (
    <ScrollView>
      <Screen>
        <Title>Teacher dashboard</Title>
        <Muted>Simple classroom preview for school deployment.</Muted>
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Stat label="Students" value="48" />
          <Stat label="Active this week" value="39" />
          <Stat label="Top language" value="Edo" />
        </View>
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: '#173024' }}>Assignments</Text>
          <Text style={{ color: '#173024', marginTop: 8 }}>• Edo greetings quiz</Text>
          <Text style={{ color: '#173024' }}>• Yoruba alphabet practice</Text>
          <Text style={{ color: '#173024' }}>• Igbo sentence reading</Text>
          <Text style={{ color: '#173024' }}>• Hausa listening task</Text>
        </Card>
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: '#173024' }}>Class progress</Text>
          <Text style={{ color: '#173024', marginTop: 8 }}>Reading: 82%</Text>
          <Text style={{ color: '#173024' }}>Writing: 69%</Text>
          <Text style={{ color: '#173024' }}>Speaking: 74%</Text>
        </Card>
      </Screen>
    </ScrollView>
  );
}
