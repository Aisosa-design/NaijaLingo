import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useApp } from '../context/AppContext';
import { Card, Muted, Screen, Stat, Title } from '../components/UI';

export default function RewardsScreen() {
  const { xp, streak, wins } = useApp();

  return (
    <ScrollView>
      <Screen>
        <Title>Rewards</Title>
        <Muted>Gamified motivation for consistent learning.</Muted>
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Stat label="XP Earned" value={xp} />
          <Stat label="Current League" value="Bronze" />
          <Stat label="Streak" value={`${streak} 🔥`} />
        </View>
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: '#173024' }}>Badges</Text>
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
            <View style={{ backgroundColor: '#F4F7F5', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 8 }}><Text style={{ fontWeight: '700' }}>Starter</Text></View>
            <View style={{ backgroundColor: '#F4F7F5', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 8 }}><Text style={{ fontWeight: '700' }}>5-Day Streak</Text></View>
          </View>
        </Card>
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: '#173024' }}>Recent wins</Text>
          <View style={{ gap: 8, marginTop: 8 }}>
            {wins.map((win, index) => <Text key={`${win}-${index}`} style={{ color: '#173024' }}>• {win}</Text>)}
          </View>
        </Card>
      </Screen>
    </ScrollView>
  );
}
