import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useApp } from '../context/AppContext';
import { Button, Card, Chip, Muted, Screen, Title } from '../components/UI';

export default function LessonScreen() {
  const { currentLanguage, currentLesson, settings, answerLesson, nextLesson, lessonIndex } = useApp();
  const [selected, setSelected] = useState(null);
  const [feedback, setFeedback] = useState('');

  const progressText = useMemo(() => `${lessonIndex} of ${currentLanguage.lessons.length} tasks complete`, [lessonIndex, currentLanguage.lessons.length]);

  return (
    <ScrollView>
      <Screen>
        <Title>{currentLanguage.name} Basics 1</Title>
        <Muted>{currentLesson.mode} lesson</Muted>

        <Card>
          <Text style={{ fontSize: 18, fontWeight: '700', color: '#173024' }}>{currentLesson.prompt}</Text>
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
            <Chip active>{currentLesson.mode}</Chip>
            {settings.captions && <Chip>Captions on</Chip>}
            {settings.textAlternative && <Chip>Text alternative enabled</Chip>}
          </View>
          <View style={{ gap: 10, marginTop: 10 }}>
            {currentLesson.choices.map((choice, idx) => (
              <Pressable key={choice} onPress={() => setSelected(idx)}>
                <Card style={{ backgroundColor: selected === idx ? '#EEF9F2' : '#FFFFFF' }}>
                  <Text style={{ fontWeight: '700', color: '#173024' }}>{choice}</Text>
                </Card>
              </Pressable>
            ))}
          </View>
          {!!feedback && <Text style={{ marginTop: 8, fontWeight: '800', color: feedback.startsWith('✅') ? '#1F8F59' : '#C24A31' }}>{feedback}</Text>}
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
            <Button title="Check" onPress={() => {
              if (selected === null) { setFeedback('Choose an answer first.'); return; }
              const correct = answerLesson(selected);
              setFeedback(correct ? `✅ ${currentLesson.explanation}` : '❌ Not quite. Try the next one.');
            }} style={{ flex: 1 }} />
            <Button title="Next" secondary onPress={() => { setSelected(null); setFeedback(''); nextLesson(); }} style={{ flex: 1 }} />
          </View>
        </Card>

        <Card>
          <Text style={{ fontSize: 18, fontWeight: '700', color: '#173024' }}>Lesson progress</Text>
          <Muted>{progressText}</Muted>
          <Text style={{ fontSize: 16, color: '#5E7368' }}>This screen demonstrates reading, writing, speaking, and inclusive learning paths.</Text>
        </Card>
      </Screen>
    </ScrollView>
  );
}
