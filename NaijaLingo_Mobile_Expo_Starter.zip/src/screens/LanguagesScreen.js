import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useApp } from '../context/AppContext';
import { Card, Chip, Muted, Screen, Title } from '../components/UI';

export default function LanguagesScreen() {
  const { languages, currentLanguageId, setCurrentLanguageId, setLessonIndex } = useApp();

  return (
    <ScrollView>
      <Screen>
        <Title>Language paths</Title>
        <Muted>Choose a language to set your current learning path.</Muted>
        {languages.map(lang => (
          <Pressable key={lang.id} onPress={() => { setCurrentLanguageId(lang.id); setLessonIndex(0); }}>
            <Card style={{ backgroundColor: currentLanguageId === lang.id ? '#F7FFF9' : '#FFFFFF' }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <Text style={{ fontSize: 20, fontWeight: '800', color: '#173024' }}>{lang.name}</Text>
                <Chip active>{lang.sample}</Chip>
              </View>
              <Muted>{lang.description}</Muted>
              {currentLanguageId === lang.id && <Text style={{ color: '#1F8F59', fontWeight: '800' }}>Selected</Text>}
            </Card>
          </Pressable>
        ))}
      </Screen>
    </ScrollView>
  );
}
