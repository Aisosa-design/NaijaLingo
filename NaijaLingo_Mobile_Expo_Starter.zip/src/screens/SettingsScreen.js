import React from 'react';
import { ScrollView, Switch, Text, View } from 'react-native';
import { useApp } from '../context/AppContext';
import { Card, Muted, Screen, Title } from '../components/UI';

function SettingRow({ label, value, onValueChange }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 8 }}>
      <Text style={{ fontSize: 16, color: '#173024', fontWeight: '600' }}>{label}</Text>
      <Switch value={value} onValueChange={onValueChange} />
    </View>
  );
}

export default function SettingsScreen() {
  const { settings, setSettings } = useApp();
  const update = (key, value) => setSettings(prev => ({ ...prev, [key]: value }));

  return (
    <ScrollView>
      <Screen>
        <Title>Accessibility settings</Title>
        <Muted>Built for learners with different needs and abilities.</Muted>
        <Card>
          <SettingRow label="Captions on lessons" value={settings.captions} onValueChange={(v) => update('captions', v)} />
          <SettingRow label="Visual-only mode" value={settings.visualOnly} onValueChange={(v) => update('visualOnly', v)} />
          <SettingRow label="High contrast" value={settings.highContrast} onValueChange={(v) => update('highContrast', v)} />
          <SettingRow label="Large text" value={settings.largeText} onValueChange={(v) => update('largeText', v)} />
          <SettingRow label="Text alternative to speaking" value={settings.textAlternative} onValueChange={(v) => update('textAlternative', v)} />
        </Card>
      </Screen>
    </ScrollView>
  );
}
