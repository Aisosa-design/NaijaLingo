import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../context/AppContext';
import { Button, Card, Muted, Pill, Screen, Stat, Title } from '../components/UI';

export default function HomeScreen() {
  const navigation = useNavigation();
  const { xp, streak, hearts, currentLanguage, currentLesson, dailyGoal, setDailyGoal } = useApp();

  return (
    <ScrollView>
      <Screen>
        <Card>
          <Pill>3MTT MVP</Pill>
          <Title>NaijaLingo</Title>
          <Muted>Read • Write • Speak • Belong</Muted>
          <Text style={{ fontSize: 18, fontWeight: '700', color: '#173024', marginTop: 4 }}>
            Learn Nigerian languages through play, culture, and inclusion.
          </Text>
          <Muted>Launch languages: Yoruba, Igbo, Hausa, Edo.</Muted>
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 8, flexWrap: 'wrap' }}>
            <Stat label="XP" value={xp} />
            <Stat label="Streak" value={`${streak} 🔥`} />
            <Stat label="Hearts" value={`${hearts} ❤️`} />
          </View>
        </Card>

        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: '#173024' }}>Continue learning</Text>
          <Muted>Today’s recommended lesson</Muted>
          <Card style={{ backgroundColor: '#1F8F59', borderColor: '#1F8F59' }}>
            <Text style={{ color: 'white', fontSize: 20, fontWeight: '800' }}>{currentLanguage.name} Basics 1</Text>
            <Text style={{ color: 'white' }}>{currentLesson.prompt}</Text>
            <Button title="Start lesson" onPress={() => navigation.navigate('Lesson')} style={{ marginTop: 6 }} />
          </Card>
        </Card>

        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: '#173024' }}>Daily goal</Text>
          <Muted>Current goal: {dailyGoal} minutes a day</Muted>
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 6 }}>
            {[5, 10, 15].map(goal => (
              <Button key={goal} title={`${goal} min`} onPress={() => setDailyGoal(goal)} secondary={dailyGoal !== goal} style={{ flex: 1 }} />
            ))}
          </View>
        </Card>

        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: '#173024' }}>Accessibility first</Text>
          <Muted>Captions, visual mode, high contrast, large text, and text alternatives to speaking.</Muted>
          <Button title="Open settings" onPress={() => navigation.navigate('Settings')} secondary />
        </Card>
      </Screen>
    </ScrollView>
  );
}
