export const languages = [
  {
    id: 'yoruba',
    name: 'Yoruba',
    sample: 'Báwo ni?',
    description: 'Greetings, reading, and everyday phrases.',
    lessons: [
      {
        mode: 'Read',
        prompt: 'What does “Báwo ni?” mean?',
        choices: ['How are you?', 'Good night', 'Thank you', 'Come here'],
        answer: 0,
        explanation: '“Báwo ni?” means “How are you?”'
      },
      {
        mode: 'Write',
        prompt: 'Which activity improves writing?',
        choices: ['Arrange letters into a greeting', 'Hide all captions', 'Skip the lesson', 'Open the leaderboard'],
        answer: 0,
        explanation: 'Writing drills include spelling and sentence building.'
      }
    ]
  },
  {
    id: 'igbo',
    name: 'Igbo',
    sample: 'Ndewo',
    description: 'Sound practice, vocabulary, and short stories.',
    lessons: [
      {
        mode: 'Read',
        prompt: 'What does “Ndewo” mean in a beginner lesson?',
        choices: ['Goodbye', 'Hello / Greetings', 'Food', 'Water'],
        answer: 1,
        explanation: '“Ndewo” is a common beginner greeting.'
      },
      {
        mode: 'Speak',
        prompt: 'Which feature helps a non-speaking learner participate?',
        choices: ['Typed response mode', 'Microphone only', 'Audio-only tasks', 'Hidden text'],
        answer: 0,
        explanation: 'Typed responses support inclusive speaking practice.'
      }
    ]
  },
  {
    id: 'hausa',
    name: 'Hausa',
    sample: 'Sannu',
    description: 'Listening drills and common conversation.',
    lessons: [
      {
        mode: 'Read',
        prompt: 'What does “Sannu” mean?',
        choices: ['School', 'Hello', 'Food', 'Dance'],
        answer: 1,
        explanation: '“Sannu” is a common Hausa greeting.'
      },
      {
        mode: 'Culture',
        prompt: 'Why include culture quests in language learning?',
        choices: ['To make lessons richer', 'To remove identity', 'To stop stories', 'To avoid reading'],
        answer: 0,
        explanation: 'Culture makes language learning more meaningful.'
      }
    ]
  },
  {
    id: 'edo',
    name: 'Edo',
    sample: 'Koyo',
    description: 'Launch language with greetings, reading, and writing drills.',
    lessons: [
      {
        mode: 'Read',
        prompt: 'What does “Koyo” mean in the starter lesson?',
        choices: ['Thank you', 'Hello / Welcome', 'Good night', 'My name is'],
        answer: 1,
        explanation: '“Koyo” is used as the Edo beginner greeting in this MVP.'
      },
      {
        mode: 'Write',
        prompt: 'Which letters form the Edo greeting?',
        choices: ['K O Y O', 'S A N N U', 'N D E W O', 'B A W O'],
        answer: 0,
        explanation: 'This spelling drill reinforces the Edo greeting.'
      },
      {
        mode: 'Speak',
        prompt: 'Which option supports inclusive speaking practice?',
        choices: ['Text alternative', 'Speech only', 'Hidden prompts', 'No feedback'],
        answer: 0,
        explanation: 'Text alternatives help deaf or non-speaking learners participate.'
      }
    ]
  }
];
