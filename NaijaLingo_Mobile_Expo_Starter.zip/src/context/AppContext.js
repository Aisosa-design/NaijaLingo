import React, { createContext, useContext, useMemo, useState } from 'react';
import { languages } from '../data/languages';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [currentLanguageId, setCurrentLanguageId] = useState('edo');
  const [xp, setXp] = useState(120);
  const [streak, setStreak] = useState(5);
  const [hearts, setHearts] = useState(5);
  const [dailyGoal, setDailyGoal] = useState(5);
  const [settings, setSettings] = useState({
    captions: true,
    visualOnly: false,
    highContrast: false,
    largeText: false,
    textAlternative: true
  });
  const [lessonIndex, setLessonIndex] = useState(0);
  const [wins, setWins] = useState([
    'Completed first Edo reading task',
    'Maintained 5-day streak',
    'Enabled accessible learning mode'
  ]);

  const currentLanguage = languages.find(l => l.id === currentLanguageId) || languages[0];
  const currentLesson = currentLanguage.lessons[lessonIndex] || currentLanguage.lessons[0];

  const answerLesson = (selectedIndex) => {
    const correct = selectedIndex === currentLesson.answer;
    if (correct) {
      setXp(v => v + 10);
      setWins(v => [`${currentLanguage.name}: completed ${currentLesson.mode.toLowerCase()} task`, ...v]);
    } else {
      setHearts(v => Math.max(0, v - 1));
    }
    return correct;
  };

  const nextLesson = () => {
    setLessonIndex(prev => {
      const next = prev + 1;
      if (next >= currentLanguage.lessons.length) {
        setStreak(v => v + 1);
        return 0;
      }
      return next;
    });
  };

  const value = useMemo(() => ({
    languages,
    currentLanguage,
    currentLanguageId,
    setCurrentLanguageId,
    xp,
    streak,
    hearts,
    dailyGoal,
    setDailyGoal,
    settings,
    setSettings,
    lessonIndex,
    setLessonIndex,
    currentLesson,
    answerLesson,
    nextLesson,
    wins
  }), [currentLanguage, currentLanguageId, xp, streak, hearts, dailyGoal, settings, lessonIndex, currentLesson, wins]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export const useApp = () => useContext(AppContext);
