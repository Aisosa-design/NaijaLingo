import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

export function Screen({ children, style }) {
  return <View style={[styles.screen, style]}>{children}</View>;
}

export function Card({ children, style }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Title({ children, style }) {
  return <Text style={[styles.title, style]}>{children}</Text>;
}

export function Muted({ children, style }) {
  return <Text style={[styles.muted, style]}>{children}</Text>;
}

export function Pill({ children, style }) {
  return <View style={[styles.pill, style]}><Text style={styles.pillText}>{children}</Text></View>;
}

export function Stat({ label, value }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  );
}

export function Button({ title, onPress, secondary = false, style }) {
  return (
    <Pressable onPress={onPress} style={[secondary ? styles.buttonSecondary : styles.buttonPrimary, style]}>
      <Text style={secondary ? styles.buttonSecondaryText : styles.buttonPrimaryText}>{title}</Text>
    </Pressable>
  );
}

export function Chip({ children, active = false }) {
  return <View style={[styles.chip, active && styles.chipActive]}><Text style={[styles.chipText, active && styles.chipTextActive]}>{children}</Text></View>;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#F8FAF8', padding: 18, gap: 14 },
  card: { backgroundColor: '#FFFFFF', borderRadius: 20, padding: 16, borderWidth: 1, borderColor: '#DDE7DF', gap: 8 },
  title: { fontSize: 26, fontWeight: '800', color: '#173024' },
  muted: { color: '#5E7368', lineHeight: 20 },
  pill: { alignSelf: 'flex-start', backgroundColor: '#DFF5E9', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999 },
  pillText: { color: '#1F8F59', fontWeight: '700', fontSize: 12 },
  stat: { flex: 1, backgroundColor: '#EEF9F2', borderRadius: 16, padding: 12, minWidth: 90 },
  statLabel: { color: '#5E7368', fontSize: 12, marginBottom: 4 },
  statValue: { fontSize: 20, fontWeight: '800', color: '#173024' },
  buttonPrimary: { backgroundColor: '#1F8F59', borderRadius: 14, paddingVertical: 13, paddingHorizontal: 14, alignItems: 'center' },
  buttonPrimaryText: { color: '#FFFFFF', fontWeight: '800' },
  buttonSecondary: { backgroundColor: '#FFFFFF', borderRadius: 14, paddingVertical: 13, paddingHorizontal: 14, alignItems: 'center', borderWidth: 1, borderColor: '#DDE7DF' },
  buttonSecondaryText: { color: '#173024', fontWeight: '800' },
  chip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 999, backgroundColor: '#F4F7F5', borderWidth: 1, borderColor: '#DDE7DF' },
  chipActive: { backgroundColor: '#FFF1E0', borderColor: '#F0C897' },
  chipText: { fontWeight: '700', color: '#173024' },
  chipTextActive: { color: '#B96A17' }
});
