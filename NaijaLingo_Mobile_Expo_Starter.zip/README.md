# NaijaLingo Mobile App Starter

This is a buildable React Native + Expo starter for NaijaLingo.

## Included
- Bottom-tab mobile navigation
- Launch languages: Yoruba, Igbo, Hausa, Edo
- Lesson flow with reading, writing, speaking, and culture examples
- XP, streak, hearts, and rewards screen
- Teacher dashboard preview
- Accessibility settings screen

## Run locally
1. Install Node.js
2. Run `npm install`
3. Run `npm start`
4. Open with Expo Go or an emulator

## Next production steps
- Add real authentication
- Persist progress with backend storage
- Add audio playback and speech practice
- Add teacher and school accounts
- Add offline lesson packs
