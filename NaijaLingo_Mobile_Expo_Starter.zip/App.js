import React from 'react';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { AppProvider } from './src/context/AppContext';
import HomeScreen from './src/screens/HomeScreen';
import LanguagesScreen from './src/screens/LanguagesScreen';
import LessonScreen from './src/screens/LessonScreen';
import RewardsScreen from './src/screens/RewardsScreen';
import TeacherScreen from './src/screens/TeacherScreen';
import SettingsScreen from './src/screens/SettingsScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function Tabs() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Languages" component={LanguagesScreen} />
      <Tab.Screen name="Lesson" component={LessonScreen} />
      <Tab.Screen name="Rewards" component={RewardsScreen} />
      <Tab.Screen name="Teacher" component={TeacherScreen} />
    </Tab.Navigator>
  );
}

const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: '#F8FAF8',
    card: '#FFFFFF',
    text: '#173024',
    primary: '#1F8F59',
    border: '#DDE7DF'
  }
};

export default function App() {
  return (
    <AppProvider>
      <NavigationContainer theme={theme}>
        <StatusBar style="dark" />
        <Stack.Navigator>
          <Stack.Screen name="NaijaLingo" component={Tabs} options={{ headerShown: false }} />
          <Stack.Screen name="Settings" component={SettingsScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </AppProvider>
  );
}
